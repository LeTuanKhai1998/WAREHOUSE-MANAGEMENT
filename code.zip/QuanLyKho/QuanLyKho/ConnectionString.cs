﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyKho
{
    class ConnectionString
    {
        public static string connectionString = "Data Source=localhost;Initial Catalog=QuanLyKhoHangv2;Integrated Security=True";
    }
}
